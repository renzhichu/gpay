module.exports = {
    name:'{$ doc.name $}',
    data:{$ doc.items | json $}
};
