    return angular.module('ngTable');
}));
